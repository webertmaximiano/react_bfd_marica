// Exercício 2 — Operações Matemáticas
// Este exercício demonstra operações matemáticas básicas com duas variáveis numéricas.

// Declara duas variáveis numéricas.
let num1 = 10;
let num2 = 5;

// Calcula e exibe a soma dos dois números no console.
console.log(`Soma: ${num1} + ${num2} = ${num1 + num2}`);

// Calcula e exibe a subtração dos dois números no console.
console.log(`Subtração: ${num1} - ${num2} = ${num1 - num2}`);

// Calcula e exibe a multiplicação dos dois números no console.
console.log(`Multiplicação: ${num1} * ${num2} = ${num1 * num2}`);

// Calcula e exibe a divisão dos dois números no console.
console.log(`Divisão: ${num1} / ${num2} = ${num1 / num2}`);
