// Exercício 1 — Saudação Personalizada
// Este exercício cria uma saudação personalizada usando uma variável para o nome.

// Declara uma variável chamada 'nome' e atribui um valor de string a ela.
let nome = "Webert Maximiano";

// Usa console.log para exibir uma mensagem no console do navegador ou Node.js.
// A mensagem inclui o valor da variável 'nome' interpolado na string usando template literals.
console.log(`Olá, ${nome}! Bem-vindo(a) ao curso de React.`);
