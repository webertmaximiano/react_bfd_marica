// Exercício 4 — Contagem com For

// Usa um loop for para iterar de 1 a 20.
// Dentro do loop, exibe o valor atual de i no console.
for (let i = 1; i <= 20; i++) {
    console.log(i);
}
